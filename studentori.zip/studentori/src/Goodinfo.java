import java.io.IOException;

//public class Goodinfo extends Men {
//    protected static int select;
//    public Goodinfo(int estimates, String name) {
//        super(estimates, name);
//    }
//
//    public void onSwitch(int select){
//
//        Men wrm = new Men(estimates, name);
////        List<String> result = new ArrayList<>();
//        switch (select){
//
//            case 1: wrm.setMen();
//        }
//    }

//    protected void onSwitch() {
//    }
//}
