import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Men extends Student {

    public Men(String name, int estimates) {
        super(name, estimates);
    }

    @Override
    public void setMW(){
        System.out.printf("Good day, please fill in info about student\n");

        try {

            File filem = new File("infomen.txt");


            if (!filem.exists()) {
                filem.createNewFile();
            }


            PrintWriter wrm = new PrintWriter(filem);


            Scanner scannerm = new Scanner(System.in);

            while (true) {
                String str = scannerm.nextLine();
                wrm.write(str);
                wrm.write("\n");


               System.out.printf("Do you want to create a new student? Enter YES to continue or EXIT to exit");
                if ("exit".equalsIgnoreCase(scannerm.nextLine())){
                    wrm.close();
                    System.exit(0);

                }
            }

        }catch(IOException e){
            System.out.printf("ERROR" + e);
        }

    }
}






