import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Women extends Student {
    public Women(String name , int estimates) {
        super(name, estimates);
    }

    @Override
    public void setMW(){
        System.out.printf("Good day, please fill in info about student\n");

        try {
            File filem = new File("infowomen.txt");

            if (!filem.exists()) {
                filem.createNewFile();
            }

            PrintWriter wrw = new PrintWriter(filem);



            Scanner scannerw = new Scanner(System.in);
            while (true) {
                String str = scannerw.nextLine();
                wrw.write(str);
                wrw.write("\n");


                System.out.printf("Do you want to create a new student? Enter YES to continue or EXIT to exit");
                if ("exit".equalsIgnoreCase(scannerw.nextLine())){
                    wrw.close();
                    System.exit(0);

                }
            }


        }catch (IOException e) {
            System.out.printf("Error" + e);
        }



    }
}

